import os
import requests

def infer_with_ollama(prompt):
    """
    Performs inference using Ollama with a host defined by the OLLAMA_HOST environment variable.

    Parameters:
        prompt (str): The prompt to send to Ollama.
    
    Returns:
        str: The generated output from Ollama.
    """
    # Get the Ollama host from environment variables, with a default value
    ollama_host = os.getenv("OLLAMA_HOST", "http://localhost:11434")
    url = f"{ollama_host}/api/generate"
    
    # Prepare the payload; adjust model and parameters as needed
    payload = {
        "model": "gemma3:1b",
        "prompt": prompt
    }
    
    # Send the request to Ollama
    response = requests.post(url, json=payload)
    response.raise_for_status()  # Raise an error for bad responses
    
    # Extract the generated text from the response, assuming it's under the "completion" key
    data = response.json()
    return data.get("completion", "No output received.")

if __name__ == '__main__':
    # Example prompt
    prompt_text = "Write a short story about a brave knight."
    result = infer_with_ollama(prompt_text)
    print("Inference Output:")
    print(result)
