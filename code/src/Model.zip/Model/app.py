from flask import Flask, request, jsonify
import joblib
import pandas as pd
import numpy as np
import requests

app = Flask(__name__)

def recommend_credit_cards(user_data):
    """
    Load the saved clustering model and scaler, preprocess the user data,
    predict the user's cluster, and return the top-3 recommended credit card types
    with associated dummy confidence scores.
    """
    # Load the pre-trained clustering model and scaler
    model = joblib.load('best_clustering_model.pkl')
    scaler = joblib.load('scaler.pkl')
    
    # Convert input user data (dict) to DataFrame and standardize it
    user_df = pd.DataFrame([user_data])
    user_scaled = scaler.transform(user_df)
    
    # Predict the cluster (using predict or fit_predict as needed)
    try:
        cluster = model.predict(user_scaled)[0]
    except AttributeError:
        cluster = model.fit_predict(user_scaled)[0]
    
    # Example mapping from clusters to recommended credit card types.
    cluster_to_cards = {
        0: ['Travel', 'Premium', 'Rewards'],
        1: ['Dining', 'Cashback', 'Rewards'],
        2: ['Cashback', 'Online Shopping', 'Rewards'],
        3: ['Business', 'Premium', 'Travel'],
        4: ['Student', 'Cashback', 'Online Shopping'],
        5: ['Premium', 'Travel', 'Dining'],
        6: ['Rewards', 'Cashback', 'Dining']
    }
    
    recommended_cards = cluster_to_cards.get(cluster, [])
    # Assign dummy confidence scores (for demonstration purposes)
    confidence_scores = [0.9, 0.8, 0.7]
    recommendations = list(zip(recommended_cards, confidence_scores))
    return recommendations

def generate_analysis(user_data, recommendations):
    """
    Use Ollama's gemma3:1b model to generate a detailed analysis of the user's spending data
    along with the top-3 recommended credit card types.
    """
    prompt = (
        f"User data: {user_data}\n"
        f"Top recommendations: {recommendations}\n"
        "Generate a detailed analysis of the user's spending behavior and explain why these "
        "credit card recommendations might be beneficial."
    )
    
    # Use the Ollama API with gemma3:1b
    url = "http://localhost:11434/api/generate"
    payload = {
        "model": "gemma3:1b",
        "prompt": prompt,
    }
    
    try:
        response = requests.post(url, json=payload)
        response.raise_for_status()
        response_data = response.json()
        # Assuming the response contains the generated analysis in the "completion" key.
        analysis = response_data.get("completion", "No analysis available")
    except Exception as e:
        analysis = f"Error generating analysis: {str(e)}"
    
    return analysis

@app.route("/predict", methods=["POST"])
def predict():
    """
    Expects a JSON payload with a key "user_data" containing 9 parameters:
        - age, annual_income, credit_score, groceries_spending, entertainment_spending,
          travel_spending, dining_spending, online_shopping, late_payments
    Returns:
        JSON object containing the top-3 credit card recommendations and an analysis.
    """
    data = request.get_json()
    user_data = data.get("user_data")
    
    if not user_data:
        return jsonify({"error": "No user_data provided"}), 400
    
    # Generate recommendations using the inference function
    recommendations = recommend_credit_cards(user_data)
    
    # Generate a detailed analysis using Ollama's gemma3:1b model
    analysis = generate_analysis(user_data, recommendations)
    
    return jsonify({
        "recommendations": recommendations,
        "analysis": analysis
    })

if __name__ == "__main__":
    app.run(debug=True)

